def mutate(word):
    outlist=[]
    letters='abcdefghijklmnopqrstuvwxyz'
    #insert a character
    for i in range(len(word)+1):
        for j in range(26):
            outlist.append(word[:i]+letters[j]+word[i:])
    #deleting a character
    for i in range(len(word)):
        outlist.append(word[:i]+word[i+1:])
    #replacing a character
    for i in range(len(word)):
        for j in range(26):
            outlist.append(word[:i]+letters[j]+word[i+1:])
    #swapping character
    cword=[]
    outword=""
    for i in range(len(word)-1):
        for j in range(i+1,len(word)):
            cword=list(word)
            cword[i],cword[j]=cword[j],cword[i]
    #converting list to string
        str1="".join(cword)
        outlist.append(str1)
        #print(outlist)
        return outlist
def nearlyeq(word1,word2):
    if len(word1)<len(word2):
        word1,word2=word2,word1
        return word1 in mutate(word2)
    else:
        return word1 in mutate(word2)
a=input("Enter word 1--")
b=input("Enter word 2 -- ")
print(nearlyeq(a,b))
