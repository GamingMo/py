def cmp(t1,t2):
    return bool(t1>t2),bool(t1<t2)
   
t = (1,2,3,4,5)
u = (4,5,6,7)
print("Comparing tuple t & u",cmp(t,u))
print("Length of t",len(t))
print("Max in tuple t:",max(t))
print("Min in tuple:",min(t))
print("Tuple sequence",tuple(t))
print("Index of 1 in t:",t.index(1))
print("Sum of tuple t:",sum(t))