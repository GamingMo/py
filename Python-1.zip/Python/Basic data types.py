#Demonstration of basic data-types
a = 5
b = 5.0
c = 2+4j
print(type(a))
print(type(b))
print(type(c))

#Creating a string
string1 = "Welcome here"
print(string1)

#Creating a list
List = ["Skit","Jagatpura","Jaipur"]
print(List[0])
print(List[1])

#Creating a tuple

List1 = [1,2,3,4,5,6]
print("\n Tuple using List:")
print(tuple(List1))

#Creating a set
set1 = set()
set1.add(8)
set1.add(6)
print("\n Set Created is")
print(set1)

