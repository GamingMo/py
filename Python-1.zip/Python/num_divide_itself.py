num=int(input("ENTER THE NUMBER -- "))
temp=num
l1=[]
count=0
while(temp!=0):
    rem=int(temp%10)
    l1.append(rem)
    temp=int(temp/10)
for i in l1:
    if(i==0):
        print("zero encountered")
        continue
    if(num%i==0):
        count=count+1
if(count==len(l1)):
    print("All digits divide")
else:
    print("Not All digits divide")
    
