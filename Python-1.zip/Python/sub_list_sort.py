def Sort1(sub_li):
    sub_li.sort(key=lambda x:x[1])
    return sub_li

sub_li=[["Sam",10], ["Harry", 5], ["Dune", 20], ["Peter", 1]]
print(Sort1(sub_li))
