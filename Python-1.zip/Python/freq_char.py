import os
f=open("deepa.py")
count=dict()
for line in f:
    for ch in line:
        if ch in count:
            count[ch]=count[ch]+1
        else:
            count[ch]=1

filename,file_extension=os.path.splitext("deepa.py")

print("file_extension==",file_extension)
if file_extension=='.py':
    print("its python program file")
elif file_extension==".txt":
    print("its a txt file")
elif file_extension==".c":
    print("its a c program file")
f.close()
