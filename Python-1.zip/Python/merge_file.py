f1=open("file1.txt",'a')
f2=open("file2.txt",'r')

for line in f2:
    f1.write("\n")
    f1.write(line)
    f1.write("\n")

f1.close()
f2.close()
    


