def insertSort(arr):
    for index in range(1, len(arr)):
        CurrentValue=arr[index]
        position=index
        while position>0 and arr[position-1]>CurrentValue:
            arr[position]=arr[position-1]
            position-=1
        arr[position]=CurrentValue


nlist = [14,6,43,54,57,41,5,21,70]
insertSort(nlist)
print(nlist)

               
