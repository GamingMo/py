L1 = list()
L2 = list([10,20,"abc"])
L1 = list(range(0,6))
print(L2[0])
print(L2[-1])
L2[0] = "4"
print(L2[:])
print(L2[0:1])
