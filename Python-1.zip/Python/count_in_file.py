file=input("Enter filename")
f=open(file, 'r')
l=w=c=0
for line in f:
    words=line.split()
    l+=1
    for word in words:
        w+=1
        for ch in word:
            c+=1
print("No. of lines :- ",l)
print("No. of words :- ",w)
print("No. of character :- ",c)
