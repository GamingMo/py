def count(s, m, n):
    table=[0 for k in range(n+1)]
    table[0]=1
    for i in range(m):
        for j in range(s[i], n+1):
            table[j]=table[j]+table[j-s[i]]
        #table is according to 0/1 knapsack
        print(table)
    return table[n]

arr=[1,2,3]
m=len(arr)
n=5
x=count(arr, m, n)
print("Maximum possibilities are :- ", x)

