file=open("xyz.txt",'r')
n=int(input("Enter the no. of lines to read :- "))
count=0
for line in file:
    if(count<n):
        print(line)
        count+=1
    else:
        break
