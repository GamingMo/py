def convert24(str1):
    if str1[-2:]=="AM" and str1[:2]=="12":
        return "00"+str1[2:-2]
    elif str1[-2:]=="AM":
        return str1[:-2]
    elif str1[-2:]=="AM" and str1[:2]=="12":
        return str1[:-2]
    else:
        return str(int(str1[:2])+12)+str1[2:8]
#print(convert24("01:00:00 PM"))
i=input("Enter The Time -- (format hour:minute:second AM/PM) -- ")
print("Converted Time -- ",convert24(i))
