file=input("Enter a filename")
f=open(file,'r')
for line in f:
    line2=""
    for ch in range(len(line)-1,-1,-1):
        line2+=line[ch]
    print(line2)

f.close()
