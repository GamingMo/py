from itertools import permutations
def allPermutations(str1):
    permlist=permutations(str1)
    for perm in list(permlist):
        print("".join(perm))


if __name__ == "__main__":
    str1="ABC"
    allPermutations(str1)
