def selectionSort(arr):
    for fillslot in range(len(arr)-1,0,-1):
        maxpos=0
        for location in range(1,fillslot+1):
            if(arr[location]>arr[maxpos]):
                maxpos=location
        temp=arr[fillslot]
        arr[fillslot]=arr[maxpos]
        arr[maxpos]=temp


nlist = [14,6,43,54,57,41,5,21,70]
selectionSort(nlist)
print(nlist)

                
