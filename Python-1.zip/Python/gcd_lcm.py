def gcd(x,y):
    return x if y==0 else gcd(y,x%y)
def lcm(x,y):
    return (x*y)//gcd(x,y)
a=int(input("Enter number 1 -- "))
b=int(input("Enter number 2 -- "))
print("gcd is ",gcd(a,b))
print("lcm is ",lcm(a,b))
